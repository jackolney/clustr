# devtools::install_github("jackolney/WhoCascade/cascade", ref = "master")
# devtools::load_all(pkg = "~/git/WhoCascade/cascade")

if (version$os == "darwin13.4.0") {
    loc <- "/Library/Frameworks/R.framework/Versions/3.3/Resources/library"
} else if (version$os == "linux-gnu") {
    loc <- "/home/DIDE/jjo11/R/x86_64-pc-linux-gnu-library/3.2/"
}

.libPaths(c(.libPaths(), loc))

library(cascade)
library(deSolve)
library(dplyr)
library(DT)
library(ggplot2)
library(ggrepel)
library(googlesheets)
library(grid)
library(gridExtra)
library(openxlsx)
library(RColorBrewer)
library(readr)
library(rhandsontable)
library(rmarkdown)
library(scales)
library(shiny)
library(shinyjs)
library(showtext)
library(testthat)
library(V8)

# Options
options(readr.num_columns = 0)
