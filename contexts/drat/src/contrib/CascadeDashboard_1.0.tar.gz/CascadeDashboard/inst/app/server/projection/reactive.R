plotOptimCostImpact.ranges  <- reactiveValues(x = NULL, y = NULL)
plotOpt_909090.ranges       <- reactiveValues(x = NULL, y = NULL)
plotOpt_DALYs.ranges        <- reactiveValues(x = NULL, y = NULL)
plotOpt_DALYs_909090.ranges <- reactiveValues(x = NULL, y = NULL)
