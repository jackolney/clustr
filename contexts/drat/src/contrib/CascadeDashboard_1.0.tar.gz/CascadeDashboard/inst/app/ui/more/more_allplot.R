tabItem(tabName = "all_plots",
    box(width = NULL,
        status = "primary",
        solidHeader = FALSE,
        plotOutput('plotAll')
    )
)
