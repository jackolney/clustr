tabItem(tabName = "country",
    column(width = 8,
        box(width = NULL,
            status = "primary",
            solidHeader = TRUE,
            title = "Map",
            collapsible = TRUE,
            collapsed = FALSE,
            uiOutput("mapWarning"),
            leafletOutput("countryMap", width = "100%", height = 500)
        ),
        box(width = NULL,
            status = "primary",
            solidHeader = TRUE,
            title = "Select Country",
            p("Please select a country from the map, the drop-down menu, or
                click 'New Country / Region' to add a new country to the database.
                Once a country is selected, or a new name has been entered the
                'Mission Control' indicators will change color and can be clicked.
                Clicking on each button will take you to the relevant data entry
                page. All indicators must be green before proceeding to calibration."),
            fluidRow(
                column(width = 6,
                    selectInput("selectCountry",
                        label = NULL,
                        choices = CountryList,
                        selected = "Brazil")
                ),
                column(width = 6,
                    bsButton(inputId = "NEW_country",
                        label = "New Country / Region",
                        style = "success",
                        type = "toggle",
                        value = FALSE,
                        size = "small",
                        block = TRUE,
                        icon = icon("plus", class = "fa-lg fa-fw", lib = "font-awesome"))
                )
            ),
            conditionalPanel(
                condition = "NEW_country.className == 'btn sbs-toggle-button btn-success btn-sm btn-block shiny-bound-input active'",
                textInput(inputId = "new_country_name", label = "", value = "", width = NULL, placeholder = "Enter name...")
            )
        )
    ),
    column(width = 4,
        box(width = NULL,
            status = "primary",
            solidHeader = TRUE,
            title = "Help Panel",
            helpText("Please click a country on the map, or select one from the drop-down menu below.
                Hit 'Reset Map' to reset map zoom.
                'Mission Control' provides additional information on available data from each country,
                click on each button to enter / edit data. Click 'New Country' to begin data entry
                for new region."),
            bsButton("resetMap", label = "RESET MAP", style = "danger", block = TRUE, size = "default"),
            downloadButton(outputId = 'downloadMasterDataSet', label = 'DOWNLOAD DATA', class = "btn btn-success btn-block"),
            HTML('
                <label for="uploadMasterDataSet" class="btn action-button btn-primary btn-block">
                    <i class="fa fa-upload"></i> UPLOAD DATA
                </label>
                <input id="uploadMasterDataSet" type="file"/>
            ')
        ),
        box(width = NULL,
            status = "primary",
            solidHeader = TRUE,
            title = "Global HIV Cascade Workshop",
            collapsible = TRUE,
            collapsed = TRUE,
            helpText("Select a country and then click 'UPLOAD' to upload 2015 Cascade estimates."),
            downloadButton(outputId = 'downloadExcel', label = 'DOWNLOAD EXCEL', class = "btn btn-success btn-block"),
            HTML('
                <label for="uploadCascade" class="btn action-button btn-primary btn-block">
                    <i class="fa fa-upload"></i> UPLOAD 2015 EXCEL
                </label>
                <input id="uploadCascade" type="file"/>
            ')
        ),
        box(width = NULL,
            status = "danger",
            title = "Mission Control",
            collapsible = TRUE,
            collapsed = FALSE,
            solidHeader = TRUE,
            bsButton(inputId = "CASCADE_FLAG",     label = "Cascade Estimates",    style = "danger", size = "small", block = TRUE, disabled = TRUE, icon = icon("times", class = "fa-lg fa-fw", lib = "font-awesome")),
            bsButton(inputId = "CD4_FLAG",         label = "CD4 Distribution",     style = "danger", size = "small", block = TRUE, disabled = TRUE, icon = icon("times", class = "fa-lg fa-fw", lib = "font-awesome")),
            bsButton(inputId = "INCIDENCE_FLAG",   label = "Incidence",            style = "danger", size = "small", block = TRUE, disabled = TRUE, icon = icon("times", class = "fa-lg fa-fw", lib = "font-awesome")),
            bsButton(inputId = "GUIDELINES_FLAG",  label = "Treatment Guidelines", style = "danger", size = "small", block = TRUE, disabled = TRUE, icon = icon("times", class = "fa-lg fa-fw", lib = "font-awesome"))
        ),
        bsAlert(anchorId = "_PROCEED_"),
        bsAlert(anchorId = "_DONOTPROCEED_"),
        fluidRow(
            column(width = 6,
                bsButton(inputId = "PREV_country", label = "Back", style = "danger",  size = "large", block = TRUE, icon = icon("arrow-left",  class = "fa-lg fa-fw", lib = "font-awesome"))
            ),
            column(width = 6,
                HTML('<button id="NEXT_country" type="button" class="btn action-button btn-success btn-lg btn-block"> Next <i class="fa fa-arrow-right fa-lg fa-fw"></i> </button>')
            )
        )
    )
)
