library(testthat)
library(CascadeDashboard)

test_check("CascadeDashboard")
