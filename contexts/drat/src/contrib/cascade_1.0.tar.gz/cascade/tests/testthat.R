library(testthat)
library(cascade)

test_check("cascade")
