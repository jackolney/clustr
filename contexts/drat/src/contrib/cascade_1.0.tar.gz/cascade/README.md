# 'cascade' -- an R package containing a deterministic model of the HIV care cascade written in C

[![Build Status](https://travis-ci.org/jackolney/cascade.svg)](https://travis-ci.org/jackolney/cascade)

This model forms the basis of the shiny application available online [here](https://jackolney.shinyapps.io/CascadeDashboard/), with the associated source code available [here](https://github.com/jackolney/CascadeDashboard).

Copyright 2016 Jack Olney
