#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>
#include "calib_model.h"

#define UnDx_500 0
#define UnDx_350500 1
#define UnDx_250350 2
#define UnDx_200250 3
#define UnDx_100200 4
#define UnDx_50100 5
#define UnDx_50 6
#define Dx_500 7
#define Dx_350500 8
#define Dx_250350 9
#define Dx_200250 10
#define Dx_100200 11
#define Dx_50100 12
#define Dx_50 13
#define Care_500 14
#define Care_350500 15
#define Care_250350 16
#define Care_200250 17
#define Care_100200 18
#define Care_50100 19
#define Care_50 20
#define PreLtfu_500 21
#define PreLtfu_350500 22
#define PreLtfu_250350 23
#define PreLtfu_200250 24
#define PreLtfu_100200 25
#define PreLtfu_50100 26
#define PreLtfu_50 27
#define Tx_Na_500 28
#define Tx_Na_350500 29
#define Tx_Na_250350 30
#define Tx_Na_200250 31
#define Tx_Na_100200 32
#define Tx_Na_50100 33
#define Tx_Na_50 34
#define Tx_A_500 35
#define Tx_A_350500 36
#define Tx_A_250350 37
#define Tx_A_200250 38
#define Tx_A_100200 39
#define Tx_A_50100 40
#define Tx_A_50 41
#define Ltfu_500 42
#define Ltfu_350500 43
#define Ltfu_250350 44
#define Ltfu_200250 45
#define Ltfu_100200 46
#define Ltfu_50100 47
#define Ltfu_50 48
#define NewInf 49
#define HivMortality 50
#define NaturalMortality 51
#define CumDiag 52
#define CumLink 53
#define CumPreL 54
#define CumInit 55
#define CumAdhr 56
#define CumLoss 57
#define Dx_Cost 58
#define Linkage_Cost 59
#define Annual_Care_Cost 60
#define Annual_ART_Cost 61

static struct myparms parms;

static struct myinc inc;

SEXP getListElement(SEXP list, const char *str)
{
    SEXP elmt = R_NilValue, names = getAttrib(list, R_NamesSymbol);
    for (int i = 0; i < length(list); i++)
    if (strcmp(CHAR(STRING_ELT(names, i)), str) == 0) {
       elmt = VECTOR_ELT(list, i);
       break;
    }
    return elmt;
}

SEXP r_calib_initmod(SEXP rp) {
    if (LENGTH(getListElement(rp, "r_par")) != 68) {
        Rf_error("Invalid Parameters.");
    }

    if (LENGTH(getListElement(rp, "r_inc")) != 7) {
        Rf_error("Invalid Incidence.");
    }

    double * p = REAL(getListElement(rp, "r_par"));
    double * i = REAL(getListElement(rp, "r_inc")); // For incidence

    parms.Nu_1 = p[0];
    parms.Nu_2 = p[1];
    parms.Nu_3 = p[2];
    parms.Nu_4 = p[3];
    parms.Nu_5 = p[4];
    parms.Nu_6 = p[5];
    parms.Rho = p[6];
    parms.Epsilon = p[7];
    parms.Kappa = p[8];
    parms.Gamma = p[9];
    parms.Theta = p[10];
    parms.Omega = p[11];
    parms.p = p[12];
    parms.s_1 = p[13];
    parms.s_2 = p[14];
    parms.s_3 = p[15];
    parms.s_4 = p[16];
    parms.s_5 = p[17];
    parms.s_6 = p[18];
    parms.s_7 = p[19];
    parms.Sigma = p[20];
    parms.Delta_1 = p[21];
    parms.Delta_2 = p[22];
    parms.Delta_3 = p[23];
    parms.Delta_4 = p[24];
    parms.Delta_5 = p[25];
    parms.Alpha_1 = p[26];
    parms.Alpha_2 = p[27];
    parms.Alpha_3 = p[28];
    parms.Alpha_4 = p[29];
    parms.Alpha_5 = p[30];
    parms.Alpha_6 = p[31];
    parms.Alpha_7 = p[32];
    parms.Tau_1 = p[33];
    parms.Tau_2 = p[34];
    parms.Tau_3 = p[35];
    parms.Tau_4 = p[36];
    parms.Tau_5 = p[37];
    parms.Tau_6 = p[38];
    parms.Tau_7 = p[39];
    parms.Mu = p[40];
    parms.ART_All = p[41];
    parms.ART_500 = p[42];
    parms.ART_350 = p[43];
    parms.ART_200 = p[44];
    parms.Dx_unitCost = p[45];
    parms.Linkage_unitCost = p[46];
    parms.Annual_Care_unitCost = p[47];
    parms.Annual_ART_unitCost = p[48];
    parms.prop_preART_500 = p[49];
    parms.prop_preART_350500 = p[50];
    parms.prop_preART_250350 = p[51];
    parms.prop_preART_200250 = p[52];
    parms.prop_preART_100200 = p[53];
    parms.prop_preART_50100 = p[54];
    parms.prop_preART_50 = p[55];
    parms.w1 = p[56];
    parms.w2 = p[57];
    parms.w3 = p[58];
    parms.w4 = p[59];
    parms.w5 = p[60];
    parms.beta = p[61];
    parms.q = p[62];
    parms.t_1 = p[63];
    parms.t_2 = p[64];
    parms.t_3 = p[65];
    parms.t_4 = p[66];
    parms.t_5 = p[67];

    for (int j = 0; j < 7; j++) {
        inc.inf[j] = i[j];
    }

    return R_NilValue;
}

SEXP r_calib_derivs(SEXP y) {
    int neq = LENGTH(y);
    SEXP ydot = PROTECT(allocVector(REALSXP, neq));
    double * yout = NULL;
    int ip = 0;
    double t = 0.0;

    calib_derivs(&neq, &t, REAL(y), REAL(ydot), yout, &ip);
    UNPROTECT(1);
    return ydot;
}

void calib_initmod(void(* odeparms) (int *, double *)) {

    DL_FUNC get_deSolve_gparms = R_GetCCallable("deSolve", "get_deSolve_gparms");

    SEXP rp = get_deSolve_gparms();

    r_calib_initmod(rp);
}

void calib_derivs(int *neq, double *t, double *y, double *ydot, double *yout, int *ip) {

    int yr = (int)ceil(*t);

    ydot[0] = (parms.prop_preART_500 *      inc.inf[yr]) -                               (parms.Nu_1 + parms.Rho + ((yr >= parms.t_1) * parms.s_1 * parms.p * parms.Theta) + ((yr >= parms.t_1) * parms.s_1 * (1-parms.p) * parms.Theta) + parms.Alpha_1 + parms.Mu) * y[UnDx_500];
    ydot[1] = (parms.prop_preART_350500 *   inc.inf[yr]) + parms.Nu_1 * y[UnDx_500] -    (parms.Nu_2 + parms.Rho + ((yr >= parms.t_2) * parms.s_2 * parms.p * parms.Theta) + ((yr >= parms.t_2) * parms.s_2 * (1-parms.p) * parms.Theta) + parms.Alpha_2 + parms.Mu) * y[UnDx_350500];
    ydot[2] = (parms.prop_preART_250350 *   inc.inf[yr]) + parms.Nu_2 * y[UnDx_350500] - (parms.Nu_3 + parms.Rho + ((yr >= parms.t_3) * parms.s_3 * parms.p * parms.Theta) + ((yr >= parms.t_3) * parms.s_3 * (1-parms.p) * parms.Theta) + parms.Alpha_3 + parms.Mu) * y[UnDx_250350];
    ydot[3] = (parms.prop_preART_200250 *   inc.inf[yr]) + parms.Nu_3 * y[UnDx_250350] - (parms.Nu_4 + parms.Rho + ((yr >= parms.t_4) * parms.s_4 * parms.p * parms.Theta) + ((yr >= parms.t_4) * parms.s_4 * (1-parms.p) * parms.Theta) + parms.Alpha_4 + parms.Mu) * y[UnDx_200250];
    ydot[4] = (parms.prop_preART_100200 *   inc.inf[yr]) + parms.Nu_4 * y[UnDx_200250] - (parms.Nu_5 + parms.Rho + ((yr >= parms.t_5) * parms.s_5 * parms.p * parms.Theta) + ((yr >= parms.t_5) * parms.s_5 * (1-parms.p) * parms.Theta) + parms.Alpha_5 + parms.Mu) * y[UnDx_100200];
    ydot[5] = (parms.prop_preART_50100 *    inc.inf[yr]) + parms.Nu_5 * y[UnDx_100200] - (parms.Nu_6 + parms.Rho + ((yr >= parms.t_5) * parms.s_6 * parms.p * parms.Theta) + ((yr >= parms.t_5) * parms.s_6 * (1-parms.p) * parms.Theta) + parms.Alpha_6 + parms.Mu) * y[UnDx_50100];
    ydot[6] = (parms.prop_preART_50 *       inc.inf[yr]) + parms.Nu_6 * y[UnDx_50100] -               (parms.Rho + ((yr >= parms.t_5) * parms.s_7 * parms.p * parms.Theta) + ((yr >= parms.t_5) * parms.s_7 * (1-parms.p) * parms.Theta) + parms.Alpha_7 + parms.Mu) * y[UnDx_50];

    ydot[7] =  parms.Rho * y[UnDx_500] - (parms.Nu_1 + parms.Epsilon +                                  ((yr >= parms.t_1) * parms.s_1 * parms.p * parms.Theta) + ((yr >= parms.t_1) * parms.s_1 * (1-parms.p) * parms.Theta) + parms.Alpha_1 + parms.Mu) * y[Dx_500];
    ydot[8] =  parms.Rho * y[UnDx_350500] + parms.Nu_1 * y[Dx_500] - (parms.Nu_2 + parms.Epsilon +      ((yr >= parms.t_2) * parms.s_2 * parms.p * parms.Theta) + ((yr >= parms.t_2) * parms.s_2 * (1-parms.p) * parms.Theta) + parms.Alpha_2 + parms.Mu) * y[Dx_350500];
    ydot[9] =  parms.Rho * y[UnDx_250350] + parms.Nu_2 * y[Dx_350500] - (parms.Nu_3 + parms.Epsilon +   ((yr >= parms.t_3) * parms.s_3 * parms.p * parms.Theta) + ((yr >= parms.t_3) * parms.s_3 * (1-parms.p) * parms.Theta) + parms.Alpha_3 + parms.Mu) * y[Dx_250350];
    ydot[10] = parms.Rho * y[UnDx_200250] + parms.Nu_3 * y[Dx_250350] - (parms.Nu_4 + parms.Epsilon +   ((yr >= parms.t_4) * parms.s_4 * parms.p * parms.Theta) + ((yr >= parms.t_4) * parms.s_4 * (1-parms.p) * parms.Theta) + parms.Alpha_4 + parms.Mu) * y[Dx_200250];
    ydot[11] = parms.Rho * y[UnDx_100200] + parms.Nu_4 * y[Dx_200250] - (parms.Nu_5 + parms.Epsilon +   ((yr >= parms.t_5) * parms.s_5 * parms.p * parms.Theta) + ((yr >= parms.t_5) * parms.s_5 * (1-parms.p) * parms.Theta) + parms.Alpha_5 + parms.Mu) * y[Dx_100200];
    ydot[12] = parms.Rho * y[UnDx_50100] + parms.Nu_5 * y[Dx_100200] - (parms.Nu_6 + parms.Epsilon +    ((yr >= parms.t_5) * parms.s_6 * parms.p * parms.Theta) + ((yr >= parms.t_5) * parms.s_6 * (1-parms.p) * parms.Theta) + parms.Alpha_6 + parms.Mu) * y[Dx_50100];
    ydot[13] = parms.Rho * y[UnDx_50] + parms.Nu_6 * y[Dx_50100] - (parms.Epsilon +                     ((yr >= parms.t_5) * parms.s_7 * parms.p * parms.Theta) + ((yr >= parms.t_5) * parms.s_7 * (1-parms.p) * parms.Theta) + parms.Alpha_7 + parms.Mu) * y[Dx_50];

    ydot[14] = (parms.q * parms.Epsilon) * y[Dx_500] - (parms.Nu_1 + parms.Kappa +                                  ((yr >= parms.t_1) * parms.p * parms.Gamma) + ((yr >= parms.t_1) * parms.s_1 * parms.p * parms.Theta) + ((yr >= parms.t_1) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_1) * parms.s_1 * (1-parms.p) * parms.Theta) + parms.Alpha_1 + parms.Mu) * y[Care_500];
    ydot[15] = (parms.q * parms.Epsilon) * y[Dx_350500] + parms.Nu_1 * y[Care_500] - (parms.Nu_2 + parms.Kappa +    ((yr >= parms.t_2) * parms.p * parms.Gamma) + ((yr >= parms.t_2) * parms.s_2 * parms.p * parms.Theta) + ((yr >= parms.t_2) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_2) * parms.s_2 * (1-parms.p) * parms.Theta) + parms.Alpha_2 + parms.Mu) * y[Care_350500];
    ydot[16] = (parms.q * parms.Epsilon) * y[Dx_250350] + parms.Nu_2 * y[Care_350500] - (parms.Nu_3 + parms.Kappa + ((yr >= parms.t_3) * parms.p * parms.Gamma) + ((yr >= parms.t_3) * parms.s_3 * parms.p * parms.Theta) + ((yr >= parms.t_3) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_3) * parms.s_3 * (1-parms.p) * parms.Theta) + parms.Alpha_3 + parms.Mu) * y[Care_250350];
    ydot[17] = (parms.q * parms.Epsilon) * y[Dx_200250] + parms.Nu_3 * y[Care_250350] - (parms.Nu_4 + parms.Kappa + ((yr >= parms.t_4) * parms.p * parms.Gamma) + ((yr >= parms.t_4) * parms.s_4 * parms.p * parms.Theta) + ((yr >= parms.t_4) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_4) * parms.s_4 * (1-parms.p) * parms.Theta) + parms.Alpha_4 + parms.Mu) * y[Care_200250];
    ydot[18] = (parms.q * parms.Epsilon) * y[Dx_100200] + parms.Nu_4 * y[Care_200250] - (parms.Nu_5 + parms.Kappa + ((yr >= parms.t_5) * parms.p * parms.Gamma) + ((yr >= parms.t_5) * parms.s_5 * parms.p * parms.Theta) + ((yr >= parms.t_5) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_5) * parms.s_5 * (1-parms.p) * parms.Theta) + parms.Alpha_5 + parms.Mu) * y[Care_100200];
    ydot[19] = (parms.q * parms.Epsilon) * y[Dx_50100] + parms.Nu_5 * y[Care_100200] - (parms.Nu_6 + parms.Kappa +  ((yr >= parms.t_5) * parms.p * parms.Gamma) + ((yr >= parms.t_5) * parms.s_6 * parms.p * parms.Theta) + ((yr >= parms.t_5) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_5) * parms.s_6 * (1-parms.p) * parms.Theta) + parms.Alpha_6 + parms.Mu) * y[Care_50100];
    ydot[20] = (parms.q * parms.Epsilon) * y[Dx_50] + parms.Nu_6 * y[Care_50100] - (parms.Kappa +                   ((yr >= parms.t_5) * parms.p * parms.Gamma) + ((yr >= parms.t_5) * parms.s_7 * parms.p * parms.Theta) + ((yr >= parms.t_5) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_5) * parms.s_7 * (1-parms.p) * parms.Theta) + parms.Alpha_7 + parms.Mu) * y[Care_50];

    ydot[21] = parms.Kappa * y[Care_500] + ((1-parms.q) * parms.Epsilon) * y[Dx_500] - (parms.Nu_1 +                                        ((yr >= parms.t_1) * parms.s_1 * parms.p * parms.Theta) + ((yr >= parms.t_1) * parms.s_1 * (1-parms.p) * parms.Theta) + parms.Alpha_1 + parms.Mu) * y[PreLtfu_500];
    ydot[22] = parms.Kappa * y[Care_350500] + parms.Nu_1 * y[PreLtfu_500] + ((1-parms.q) * parms.Epsilon) * y[Dx_350500] - (parms.Nu_2 +    ((yr >= parms.t_2) * parms.s_2 * parms.p * parms.Theta) + ((yr >= parms.t_2) * parms.s_2 * (1-parms.p) * parms.Theta) + parms.Alpha_2 + parms.Mu) * y[PreLtfu_350500];
    ydot[23] = parms.Kappa * y[Care_250350] + parms.Nu_2 * y[PreLtfu_350500] + ((1-parms.q) * parms.Epsilon) * y[Dx_250350] - (parms.Nu_3 + ((yr >= parms.t_3) * parms.s_3 * parms.p * parms.Theta) + ((yr >= parms.t_3) * parms.s_3 * (1-parms.p) * parms.Theta) + parms.Alpha_3 + parms.Mu) * y[PreLtfu_250350];
    ydot[24] = parms.Kappa * y[Care_200250] + parms.Nu_3 * y[PreLtfu_250350] + ((1-parms.q) * parms.Epsilon) * y[Dx_200250] - (parms.Nu_4 + ((yr >= parms.t_4) * parms.s_4 * parms.p * parms.Theta) + ((yr >= parms.t_4) * parms.s_4 * (1-parms.p) * parms.Theta) + parms.Alpha_4 + parms.Mu) * y[PreLtfu_200250];
    ydot[25] = parms.Kappa * y[Care_100200] + parms.Nu_4 * y[PreLtfu_200250] + ((1-parms.q) * parms.Epsilon) * y[Dx_100200] - (parms.Nu_5 + ((yr >= parms.t_5) * parms.s_5 * parms.p * parms.Theta) + ((yr >= parms.t_5) * parms.s_5 * (1-parms.p) * parms.Theta) + parms.Alpha_5 + parms.Mu) * y[PreLtfu_100200];
    ydot[26] = parms.Kappa * y[Care_50100] + parms.Nu_5 * y[PreLtfu_100200] + ((1-parms.q) * parms.Epsilon) * y[Dx_50100] - (parms.Nu_6 +   ((yr >= parms.t_5) * parms.s_6 * parms.p * parms.Theta) + ((yr >= parms.t_5) * parms.s_6 * (1-parms.p) * parms.Theta) + parms.Alpha_6 + parms.Mu) * y[PreLtfu_50100];
    ydot[27] = parms.Kappa * y[Care_50] + parms.Nu_6 * y[PreLtfu_50100] + ((1-parms.q) * parms.Epsilon) * y[Dx_50] - (                      ((yr >= parms.t_5) * parms.s_7 * parms.p * parms.Theta) + ((yr >= parms.t_5) * parms.s_7 * (1-parms.p) * parms.Theta) + parms.Alpha_7 + parms.Mu) * y[PreLtfu_50];

    ydot[28] = ((yr >= parms.t_1) * parms.s_1 * (1-parms.p) * parms.Theta) * y[PreLtfu_500] +    (((yr >= parms.t_1) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_1) * parms.s_1 * (1-parms.p) * parms.Theta)) * y[Care_500] +    ((yr >= parms.t_1) * parms.s_1 * (1-parms.p) * parms.Theta) * y[Dx_500] +    ((yr >= parms.t_1) * parms.s_1 * (1-parms.p) * parms.Theta) * y[UnDx_500] - (parms.Nu_1 + parms.Omega + parms.Sigma + parms.Alpha_1 + parms.Mu) * y[Tx_Na_500];
    ydot[29] = ((yr >= parms.t_2) * parms.s_2 * (1-parms.p) * parms.Theta) * y[PreLtfu_350500] + (((yr >= parms.t_2) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_2) * parms.s_2 * (1-parms.p) * parms.Theta)) * y[Care_350500] + ((yr >= parms.t_2) * parms.s_2 * (1-parms.p) * parms.Theta) * y[Dx_350500] + ((yr >= parms.t_2) * parms.s_2 * (1-parms.p) * parms.Theta) * y[UnDx_350500] + parms.Nu_1 * y[Tx_Na_500] - (parms.Nu_2 + parms.Omega + parms.Sigma + parms.Alpha_2 + parms.Mu) * y[Tx_Na_350500];
    ydot[30] = ((yr >= parms.t_3) * parms.s_3 * (1-parms.p) * parms.Theta) * y[PreLtfu_250350] + (((yr >= parms.t_3) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_3) * parms.s_3 * (1-parms.p) * parms.Theta)) * y[Care_250350] + ((yr >= parms.t_3) * parms.s_3 * (1-parms.p) * parms.Theta) * y[Dx_250350] + ((yr >= parms.t_3) * parms.s_3 * (1-parms.p) * parms.Theta) * y[UnDx_250350] + parms.Nu_2 * y[Tx_Na_350500] - (parms.Nu_3 + parms.Omega + parms.Sigma + parms.Alpha_3 + parms.Mu) * y[Tx_Na_250350];
    ydot[31] = ((yr >= parms.t_4) * parms.s_4 * (1-parms.p) * parms.Theta) * y[PreLtfu_200250] + (((yr >= parms.t_4) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_4) * parms.s_4 * (1-parms.p) * parms.Theta)) * y[Care_200250] + ((yr >= parms.t_4) * parms.s_4 * (1-parms.p) * parms.Theta) * y[Dx_200250] + ((yr >= parms.t_4) * parms.s_4 * (1-parms.p) * parms.Theta) * y[UnDx_200250] + parms.Nu_3 * y[Tx_Na_250350] - (parms.Nu_4 + parms.Omega + parms.Sigma + parms.Alpha_4 + parms.Mu) * y[Tx_Na_200250];
    ydot[32] = ((yr >= parms.t_5) * parms.s_5 * (1-parms.p) * parms.Theta) * y[PreLtfu_100200] + (((yr >= parms.t_5) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_5) * parms.s_5 * (1-parms.p) * parms.Theta)) * y[Care_100200] + ((yr >= parms.t_5) * parms.s_5 * (1-parms.p) * parms.Theta) * y[Dx_100200] + ((yr >= parms.t_5) * parms.s_5 * (1-parms.p) * parms.Theta) * y[UnDx_100200] + parms.Nu_4 * y[Tx_Na_200250] - (parms.Nu_5 + parms.Omega + parms.Sigma + parms.Alpha_5 + parms.Mu) * y[Tx_Na_100200];
    ydot[33] = ((yr >= parms.t_5) * parms.s_6 * (1-parms.p) * parms.Theta) * y[PreLtfu_50100] +  (((yr >= parms.t_5) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_5) * parms.s_6 * (1-parms.p) * parms.Theta)) * y[Care_50100] +  ((yr >= parms.t_5) * parms.s_6 * (1-parms.p) * parms.Theta) * y[Dx_50100] +  ((yr >= parms.t_5) * parms.s_6 * (1-parms.p) * parms.Theta) * y[UnDx_50100] + parms.Nu_5 * y[Tx_Na_100200] - (parms.Nu_6 + parms.Omega + parms.Sigma + parms.Alpha_6 + parms.Mu) * y[Tx_Na_50100];
    ydot[34] = ((yr >= parms.t_5) * parms.s_7 * (1-parms.p) * parms.Theta) * y[PreLtfu_50] +     (((yr >= parms.t_5) * (1-parms.p) * parms.Gamma) + ((yr >= parms.t_5) * parms.s_7 * (1-parms.p) * parms.Theta)) * y[Care_50] +     ((yr >= parms.t_5) * parms.s_7 * (1-parms.p) * parms.Theta) * y[Dx_50] +     ((yr >= parms.t_5) * parms.s_7 * (1-parms.p) * parms.Theta) * y[UnDx_50] + parms.Nu_6 * y[Tx_Na_50100] - (parms.Omega + parms.Sigma + parms.Alpha_7 + parms.Mu) * y[Tx_Na_50];

    ydot[35] = parms.Sigma * y[Tx_Na_500] +     ((yr >= parms.t_1) * parms.s_1 * parms.p * parms.Theta) * y[PreLtfu_500] +    (((yr >= parms.t_1) * parms.p * parms.Gamma) + ((yr >= parms.t_1) * parms.s_1 * parms.p * parms.Theta)) * y[Care_500] +    ((yr >= parms.t_1) * parms.s_1 * parms.p * parms.Theta) * y[Dx_500] +    ((yr >= parms.t_1) * parms.s_1 * parms.p * parms.Theta) * y[UnDx_500] - (parms.Omega + parms.Tau_1 + parms.Mu) * y[Tx_A_500];
    ydot[36] = parms.Sigma * y[Tx_Na_350500] +  ((yr >= parms.t_2) * parms.s_2 * parms.p * parms.Theta) * y[PreLtfu_350500] + (((yr >= parms.t_2) * parms.p * parms.Gamma) + ((yr >= parms.t_2) * parms.s_2 * parms.p * parms.Theta)) * y[Care_350500] + ((yr >= parms.t_2) * parms.s_2 * parms.p * parms.Theta) * y[Dx_350500] + ((yr >= parms.t_2) * parms.s_2 * parms.p * parms.Theta) * y[UnDx_350500] + parms.Delta_1 * y[Tx_A_250350] - (parms.Omega + parms.Tau_2 + parms.Mu) * y[Tx_A_350500];
    ydot[37] = parms.Sigma * y[Tx_Na_250350] +  ((yr >= parms.t_3) * parms.s_3 * parms.p * parms.Theta) * y[PreLtfu_250350] + (((yr >= parms.t_3) * parms.p * parms.Gamma) + ((yr >= parms.t_3) * parms.s_3 * parms.p * parms.Theta)) * y[Care_250350] + ((yr >= parms.t_3) * parms.s_3 * parms.p * parms.Theta) * y[Dx_250350] + ((yr >= parms.t_3) * parms.s_3 * parms.p * parms.Theta) * y[UnDx_250350] + parms.Delta_2 * y[Tx_A_200250] - (parms.Delta_1 + parms.Omega + parms.Tau_3 + parms.Mu) * y[Tx_A_250350];
    ydot[38] = parms.Sigma * y[Tx_Na_200250] +  ((yr >= parms.t_4) * parms.s_4 * parms.p * parms.Theta) * y[PreLtfu_200250] + (((yr >= parms.t_4) * parms.p * parms.Gamma) + ((yr >= parms.t_4) * parms.s_4 * parms.p * parms.Theta)) * y[Care_200250] + ((yr >= parms.t_4) * parms.s_4 * parms.p * parms.Theta) * y[Dx_200250] + ((yr >= parms.t_4) * parms.s_4 * parms.p * parms.Theta) * y[UnDx_200250] + parms.Delta_3 * y[Tx_A_100200] - (parms.Delta_2 + parms.Omega + parms.Tau_4 + parms.Mu) * y[Tx_A_200250];
    ydot[39] = parms.Sigma * y[Tx_Na_100200] +  ((yr >= parms.t_5) * parms.s_5 * parms.p * parms.Theta) * y[PreLtfu_100200] + (((yr >= parms.t_5) * parms.p * parms.Gamma) + ((yr >= parms.t_5) * parms.s_5 * parms.p * parms.Theta)) * y[Care_100200] + ((yr >= parms.t_5) * parms.s_5 * parms.p * parms.Theta) * y[Dx_100200] + ((yr >= parms.t_5) * parms.s_5 * parms.p * parms.Theta) * y[UnDx_100200] + parms.Delta_4 * y[Tx_A_50100] - (parms.Delta_3 + parms.Omega + parms.Tau_5 + parms.Mu) * y[Tx_A_100200];
    ydot[40] = parms.Sigma * y[Tx_Na_50100] +   ((yr >= parms.t_5) * parms.s_6 * parms.p * parms.Theta) * y[PreLtfu_50100] +  (((yr >= parms.t_5) * parms.p * parms.Gamma) + ((yr >= parms.t_5) * parms.s_6 * parms.p * parms.Theta)) * y[Care_50100] +  ((yr >= parms.t_5) * parms.s_6 * parms.p * parms.Theta) * y[Dx_50100] +  ((yr >= parms.t_5) * parms.s_6 * parms.p * parms.Theta) * y[UnDx_50100] + parms.Delta_5 * y[Tx_A_50] - (parms.Delta_4 + parms.Omega + parms.Tau_6 + parms.Mu) * y[Tx_A_50100];
    ydot[41] = parms.Sigma * y[Tx_Na_50] +      ((yr >= parms.t_5) * parms.s_7 * parms.p * parms.Theta) * y[PreLtfu_50] +     (((yr >= parms.t_5) * parms.p * parms.Gamma) + ((yr >= parms.t_5) * parms.s_7 * parms.p * parms.Theta)) * y[Care_50] +     ((yr >= parms.t_5) * parms.s_7 * parms.p * parms.Theta) * y[Dx_50] +     ((yr >= parms.t_5) * parms.s_7 * parms.p * parms.Theta) * y[UnDx_50] - (parms.Delta_5 + parms.Omega + parms.Tau_7 + parms.Mu) * y[Tx_A_50];

    ydot[42] = parms.Omega * (y[Tx_Na_500] +    y[Tx_A_500]) -   (parms.Nu_1 + parms.Alpha_1 + parms.Mu) * y[Ltfu_500];
    ydot[43] = parms.Omega * (y[Tx_Na_350500] + y[Tx_A_350500]) + parms.Nu_1 * y[Ltfu_500] - (parms.Nu_2 + parms.Alpha_2 + parms.Mu) * y[Ltfu_350500];
    ydot[44] = parms.Omega * (y[Tx_Na_250350] + y[Tx_A_250350]) + parms.Nu_2 * y[Ltfu_350500] - (parms.Nu_3 + parms.Alpha_3 + parms.Mu) * y[Ltfu_250350];
    ydot[45] = parms.Omega * (y[Tx_Na_200250] + y[Tx_A_200250]) + parms.Nu_3 * y[Ltfu_250350] - (parms.Nu_4 + parms.Alpha_4 + parms.Mu) * y[Ltfu_200250];
    ydot[46] = parms.Omega * (y[Tx_Na_100200] + y[Tx_A_100200]) + parms.Nu_4 * y[Ltfu_200250] - (parms.Nu_5 + parms.Alpha_5 + parms.Mu) * y[Ltfu_100200];
    ydot[47] = parms.Omega * (y[Tx_Na_50100] +  y[Tx_A_50100]) +  parms.Nu_5 * y[Ltfu_100200] - (parms.Nu_6 + parms.Alpha_6 + parms.Mu) * y[Ltfu_50100];
    ydot[48] = parms.Omega * (y[Tx_Na_50] +     y[Tx_A_50]) +     parms.Nu_6 * y[Ltfu_50100] - (parms.Alpha_7 + parms.Mu) * y[Ltfu_50];

    ydot[49] = parms.prop_preART_500 * inc.inf[yr] + parms.prop_preART_350500 * inc.inf[yr] + parms.prop_preART_250350 * inc.inf[yr] + parms.prop_preART_200250 * inc.inf[yr] + parms.prop_preART_100200 * inc.inf[yr] + parms.prop_preART_50100 * inc.inf[yr] + parms.prop_preART_50 * inc.inf[yr];
    ydot[50] = parms.Alpha_1 * (y[UnDx_500] + y[Dx_500] + y[Care_500] + y[PreLtfu_500] + y[Tx_Na_500]) + parms.Alpha_2 * (y[UnDx_350500] + y[Dx_350500] + y[Care_350500] + y[PreLtfu_350500] + y[Tx_Na_350500]) + parms.Alpha_3 * (y[UnDx_250350] + y[Dx_250350] + y[Care_250350] + y[PreLtfu_250350] + y[Tx_Na_250350]) + parms.Alpha_4 * (y[UnDx_200250] + y[Dx_200250] + y[Care_200250] + y[PreLtfu_200250] + y[Tx_Na_200250]) + parms.Alpha_5 * (y[UnDx_100200] + y[Dx_100200] + y[Care_100200] + y[PreLtfu_100200] + y[Tx_Na_100200]) + parms.Alpha_6 * (y[UnDx_50100] + y[Dx_50100] + y[Care_50100] + y[PreLtfu_50100] + y[Tx_Na_50100]) + parms.Alpha_7 * (y[UnDx_50] + y[Dx_50] + y[Care_50] + y[PreLtfu_50] + y[Tx_Na_50]) + parms.Tau_1 * y[Tx_A_500] + parms.Tau_2 * y[Tx_A_350500] + parms.Tau_3 * y[Tx_A_250350] + parms.Tau_4 * y[Tx_A_200250] + parms.Tau_5 * y[Tx_A_100200] + parms.Tau_6 * y[Tx_A_50100] + parms.Tau_7 * y[Tx_A_50];
    ydot[51] = parms.Mu * (y[UnDx_500] + y[UnDx_350500] + y[UnDx_250350] + y[UnDx_200250] + y[UnDx_100200] + y[UnDx_50100] + y[UnDx_50] + y[Dx_500] + y[Dx_350500] + y[Dx_250350] + y[Dx_200250] + y[Dx_100200] + y[Dx_50100] + y[Dx_50] + y[Care_500] + y[Care_350500] + y[Care_250350] + y[Care_200250] + y[Care_100200] + y[Care_50100] + y[Care_50] + y[PreLtfu_500] + y[PreLtfu_350500] + y[PreLtfu_250350] + y[PreLtfu_200250] + y[PreLtfu_100200] + y[PreLtfu_50100] + y[PreLtfu_50] + y[Tx_Na_500] + y[Tx_Na_350500] + y[Tx_Na_250350] + y[Tx_Na_200250] + y[Tx_Na_100200] + y[Tx_Na_50100] + y[Tx_Na_50] + y[Tx_A_500] + y[Tx_A_350500] + y[Tx_A_250350] + y[Tx_A_200250] + y[Tx_A_100200] + y[Tx_A_50100] + y[Tx_A_50] + y[Ltfu_500] + y[Ltfu_350500] + y[Ltfu_250350] + y[Ltfu_200250] + y[Ltfu_100200] + y[Ltfu_50100] + y[Ltfu_50]);

    ydot[52] = (y[UnDx_500] + y[UnDx_350500] + y[UnDx_250350] + y[UnDx_200250] + y[UnDx_100200] + y[UnDx_50100] + y[UnDx_50]) * parms.Rho;
    ydot[53] = (y[Dx_500]   + y[Dx_350500]   + y[Dx_250350]   + y[Dx_200250]   + y[Dx_100200]   + y[Dx_50100]   + y[Dx_50])   * (parms.Epsilon * parms.q);
    ydot[54] = (y[Care_500] + y[Care_350500] + y[Care_250350] + y[Care_200250] + y[Care_100200] + y[Care_50100] + y[Care_50]) * parms.Kappa;
    ydot[55] = (((yr >= parms.t_1) * y[Care_500]) + ((yr >= parms.t_2) * y[Care_350500]) + ((yr >= parms.t_3) * y[Care_250350]) + ((yr >= parms.t_4) * y[Care_200250]) + ((yr >= parms.t_5) * y[Care_100200]) + ((yr >= parms.t_5) * y[Care_50100]) + ((yr >= parms.t_5) * y[Care_50])) * parms.Gamma;
    ydot[56] = (y[Tx_Na_500] + y[Tx_Na_350500] + y[Tx_Na_250350] + y[Tx_Na_200250] + y[Tx_Na_100200] + y[Tx_Na_50100] + y[Tx_Na_50]) * parms.Sigma;
    ydot[57] = (y[Tx_Na_500] + y[Tx_Na_350500] + y[Tx_Na_250350] + y[Tx_Na_200250] + y[Tx_Na_100200] + y[Tx_Na_50100] + y[Tx_Na_50] + y[Tx_A_500] + y[Tx_A_350500] + y[Tx_A_250350] + y[Tx_A_200250] + y[Tx_A_100200] + y[Tx_A_50100] + y[Tx_A_50]) * parms.Omega;

    ydot[58] = (parms.Rho * (y[UnDx_500] + y[UnDx_350500] + y[UnDx_250350] + y[UnDx_200250] + y[UnDx_100200] + y[UnDx_50100] + y[UnDx_50])) * parms.Dx_unitCost;
    ydot[59] = ((parms.q * parms.Epsilon) * (y[Dx_500] + y[Dx_350500] + y[Dx_250350] + y[Dx_200250] + y[Dx_100200] + y[Dx_50100] + y[Dx_50])) * parms.Linkage_unitCost;
    ydot[60] = (y[Care_500] + y[Care_350500] + y[Care_250350] + y[Care_200250] + y[Care_100200] + y[Care_50100] + y[Care_50]) * parms.Annual_Care_unitCost;
    ydot[61] = (y[Tx_Na_500] + y[Tx_Na_350500] + y[Tx_Na_250350] + y[Tx_Na_200250] + y[Tx_Na_100200] + y[Tx_Na_50100] + y[Tx_Na_50] + y[Tx_A_500] + y[Tx_A_350500] + y[Tx_A_250350] + y[Tx_A_200250] + y[Tx_A_100200] + y[Tx_A_50100] + y[Tx_A_50]) * parms.Annual_ART_unitCost;

}
